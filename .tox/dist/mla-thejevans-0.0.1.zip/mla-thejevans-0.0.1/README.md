# Public IceCube Analysis Tools

[![Documentation Status](https://readthedocs.org/projects/mla/badge/?version=latest)](https://mla.readthedocs.io/en/latest/?badge=latest)
[![GitHub Super-Linter](https://github.com/thejevans/mla/workflows/Lint%20Code%20Base/badge.svg)](https://github.com/marketplace/actions/super-linter)
